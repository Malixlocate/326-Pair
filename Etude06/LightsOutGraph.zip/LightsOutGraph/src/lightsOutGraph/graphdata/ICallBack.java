package lightsOutGraph.graphdata;

public interface ICallBack {
   public void callback();
}
